The tools archive's README.
